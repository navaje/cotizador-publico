<?php
// Receptor autenticado por HMAC, independiente de las sesiones del navegador.
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__.'/app/bancos.php';
date_default_timezone_set('America/Mexico_City');
function ojb_response(int $code,array $data): void {http_response_code($code);echo json_encode($data);exit;}
if(($_SERVER['REQUEST_METHOD']??'')!=='POST')ojb_response(405,['ok'=>false]);
$config=ojb_config();$secret=(string)($config['secreto']??'');
if(!preg_match('/^[a-f0-9]{64}$/D',$secret))ojb_response(503,['ok'=>false,'error'=>'Configura la conexión.']);
$ts=$_SERVER['HTTP_X_OJ_TIMESTAMP']??'';$sig=$_SERVER['HTTP_X_OJ_SIGNATURE']??'';
if(!ctype_digit($ts) || abs(time()-(int)$ts)>300 || (int)($_SERVER['CONTENT_LENGTH']??0)>200000)ojb_response(401,['ok'=>false]);
$body=file_get_contents('php://input',false,null,0,200001);
if(strlen($body)>200000 || !hash_equals(hash_hmac('sha256',$ts.'.'.$body,$secret),$sig))ojb_response(401,['ok'=>false]);
try {
    $data=json_decode($body,true,32,JSON_THROW_ON_ERROR);
    foreach(['correo','id','from','subject','body'] as $k)if(!isset($data[$k]) || !is_string($data[$k]))throw new InvalidArgumentException('Formato inválido.');
    if(strcasecmp($data['correo'],$config['correo']??'')!==0)ojb_response(403,['ok'=>false]);
    $r=ojb_parse($data['from'],$data['subject'],$data['body']);
    if($r['cuenta']!==($config['cuenta']??''))ojb_response(403,['ok'=>false,'error'=>'Cuenta no configurada.']);
    require_once __DIR__.'/db.php';
    // Las tablas se crean al abrir Movimientos como administrador, no desde Internet.
    $result=ojb_import($pdo,$r,$data['id'],'gmail','Sincronización Gmail');
    ojb_response(200,['ok'=>true]+$result);
} catch(InvalidArgumentException $e) {ojb_response(422,['ok'=>false,'error'=>$e->getMessage()]);}
catch(Throwable $e) {error_log('OJ bancos receptor: '.$e->getMessage());ojb_response(503,['ok'=>false,'error'=>'No se pudo registrar el movimiento.']);}
