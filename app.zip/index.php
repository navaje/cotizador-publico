<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';

$stmtEmpresa = $pdo->query("SELECT * FROM empresa LIMIT 1");
$empresa = $stmtEmpresa->fetch();

$solicitud = null;
if (isset($_GET['solicitud_id']) && is_numeric($_GET['solicitud_id'])) {
    $stmtSolicitud = $pdo->prepare("SELECT * FROM solicitudes_servicio WHERE id = ? LIMIT 1");
    $stmtSolicitud->execute([(int)$_GET['solicitud_id']]);
    $solicitud = $stmtSolicitud->fetch();
}

$logoHtml = '';
$logoPath = __DIR__ . '/' . ($empresa['logo'] ?? 'assets/logo.png');

if (file_exists($logoPath)) {
    $extension = strtolower(pathinfo($logoPath, PATHINFO_EXTENSION));
    $mime = 'image/png';

    if ($extension === 'jpg' || $extension === 'jpeg') $mime = 'image/jpeg';
    if ($extension === 'webp') $mime = 'image/webp';

    $logoHtml = '<img src="data:' . $mime . ';base64,' . base64_encode(file_get_contents($logoPath)) . '" style="height:60px; display:block; margin-bottom:8px;">';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Cotizador Ojo Jarocho</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
*{box-sizing:border-box}
body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#eef3f8;color:#1f2937;padding:24px}
.wrap{max-width:1100px;margin:auto;background:#fff;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.08);overflow:hidden}
.topbar{background:#0d3b66;color:#fff;padding:22px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}
.topbar h1{margin:0}
.top-link{background:#dbe7f3;color:#0d3b66;text-decoration:none;padding:10px 14px;border-radius:8px;font-weight:bold}
.content{padding:24px}
.empresa-header{border-bottom:3px solid #0d3b66;padding-bottom:15px;margin-bottom:20px;display:flex;justify-content:space-between;gap:20px;flex-wrap:wrap}
.empresa-nombre{font-size:22px;font-weight:bold;color:#0d3b66}
.empresa-info{font-size:13px;line-height:1.5}
.doc-title{font-size:24px;font-weight:bold;color:#0d3b66}
.section{margin-bottom:24px;border:1px solid #e5e7eb;border-radius:12px;padding:20px;background:#fafcff}
.section h2{margin:0 0 16px;color:#0d3b66}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:14px}
.grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
.full{grid-column:1/-1}
label{display:block;font-weight:bold;margin-bottom:6px;font-size:14px}
input,textarea{width:100%;padding:10px;border:1px solid #cfd8e3;border-radius:8px;font-size:14px;background:#fff}
textarea{min-height:85px;resize:vertical}
table{width:100%;border-collapse:collapse;margin-top:10px;background:#fff}
th{background:#0d3b66;color:#fff;padding:10px;text-align:left;font-size:13px}
td{border:1px solid #ddd;padding:8px;vertical-align:middle}
.actions{margin-top:12px;display:flex;gap:10px;flex-wrap:wrap}
.btn{padding:10px 14px;border:none;border-radius:8px;font-weight:bold;cursor:pointer;font-size:14px}
.btn-primary{background:#0d3b66;color:#fff}
.btn-secondary{background:#dbe7f3;color:#0d3b66}
.btn-danger{background:#fee2e2;color:#b91c1c}
.btn-green{background:#dcfce7;color:#166534}
.btn-orange{background:#ffedd5;color:#c2410c}
.totals{text-align:right;font-size:20px;font-weight:bold;color:#0d3b66;margin-top:18px}
@media(max-width:900px){.grid,.grid-3{grid-template-columns:1fr}body{padding:12px}.content{padding:16px}table{display:block;overflow:auto}}
</style>
</head>
<body>

<div class="wrap">
  <div class="topbar">
    <h1>Cotizador Ojo Jarocho</h1>
    <div>
      <a class="top-link" href="dashboard.php">Dashboard</a>
      <a class="top-link" href="listado.php">Listado</a>
      <a class="top-link" href="solicitudes.php">Solicitudes</a>
      <a class="top-link" href="logout.php">Salir</a>
    </div>
  </div>

  <div class="content">
    <div class="empresa-header">
      <div>
        <?php echo $logoHtml; ?>
        <div class="empresa-nombre"><?php echo htmlspecialchars($empresa['nombre'] ?? 'Ojo Jarocho'); ?></div>
        <div class="empresa-info">
          <?php echo htmlspecialchars($empresa['direccion'] ?? ''); ?><br>
          <?php echo htmlspecialchars($empresa['telefono'] ?? ''); ?> | <?php echo htmlspecialchars($empresa['email'] ?? ''); ?><br>
          <?php echo htmlspecialchars($empresa['web'] ?? ''); ?>
        </div>
      </div>
      <div class="doc-title">Generador de documentos</div>
    </div>

    <form method="POST" action="generar-pdf.php" target="_blank" id="cotizadorForm">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="modo_pdf" id="modo_pdf" value="ver">
      <input type="hidden" name="tipo_documento" id="tipo_documento" value="cotizacion">
      <input type="hidden" name="solicitud_id" value="<?php echo htmlspecialchars($solicitud['id'] ?? ''); ?>">

      <div class="section">
        <h2>Datos del cliente</h2>
        <div class="grid">
          <div>
            <label>Nombre</label>
            <input type="text" name="cliente_nombre" required value="<?php echo htmlspecialchars($solicitud['cliente_nombre'] ?? ''); ?>">
          </div>
          <div>
            <label>Teléfono</label>
            <input type="text" name="cliente_telefono" value="<?php echo htmlspecialchars($solicitud['cliente_telefono'] ?? ''); ?>">
          </div>
          <div>
            <label>Correo</label>
            <input type="email" name="cliente_email" value="<?php echo htmlspecialchars($solicitud['cliente_email'] ?? ''); ?>">
          </div>
          <div>
            <label>Proyecto</label>
            <input type="text" name="proyecto" value="<?php echo htmlspecialchars($solicitud['tipo_servicio'] ?? ''); ?>">
          </div>
          <div class="full">
            <label>Dirección / ubicación</label>
            <textarea name="cliente_direccion"><?php echo htmlspecialchars($solicitud['direccion'] ?? ''); ?></textarea>
          </div>
        </div>
      </div>

      <div class="section">
        <h2>Detalles</h2>
        <div class="grid-3">
          <div>
            <label>Vigencia</label>
            <input type="text" name="vigencia" value="15 días">
          </div>
          <div>
            <label>Método de pago</label>
            <input type="text" name="metodo_pago" value="Transferencia / Efectivo">
          </div>
          <div>
            <label>Tiempo de instalación</label>
            <input type="text" name="tiempo_instalacion" value="Sujeto a agenda y confirmación">
          </div>

          <div class="full">
            <label>Descripción</label>
            <textarea name="descripcion"><?php
if ($solicitud) {
    echo htmlspecialchars(
        "Solicitud: " . $solicitud['folio'] . "\n" .
        "Tipo de equipo: " . $solicitud['tipo_equipo'] . "\n" .
        "Marca: " . $solicitud['marca'] . "\n" .
        "Modelo: " . $solicitud['modelo'] . "\n" .
        "No. Serie: " . $solicitud['numero_serie'] . "\n\n" .
        "Falla reportada:\n" . $solicitud['falla_reportada']
    );
}
?></textarea>
          </div>

          <div class="full">
            <label>Observaciones</label>
            <textarea name="observaciones"><?php
if ($solicitud) {
    echo htmlspecialchars(
        "Persona que atiende: " . $solicitud['persona_atiende'] . "\n" .
        "Fecha preferida: " . $solicitud['fecha_preferida'] . "\n" .
        "Horario preferido: " . $solicitud['horario_preferido'] . "\n\n" .
        "Observaciones del cliente:\n" . $solicitud['observaciones']
    );
}
?></textarea>
          </div>

          <div class="full">
            <label>Condiciones</label>
            <textarea name="condiciones">La presente cotización está sujeta a disponibilidad de equipo. Los precios pueden cambiar sin previo aviso. El servicio de instalación se agenda una vez confirmado el anticipo(50%) o pago acordado.Banco: Banorte. Cuenta: 4189140075564483. Clabe interbancaria: 072910012172856793</textarea>
          </div>
        </div>
      </div>

      <div class="section">
        <h2>Productos / conceptos</h2>

        <table>
          <thead>
            <tr>
              <th style="width:45%;">Concepto</th>
              <th style="width:15%;">Cantidad</th>
              <th style="width:20%;">Precio</th>
              <th style="width:20%;">Acción</th>
            </tr>
          </thead>
          <tbody id="productosBody">
            <tr>
              <td><input type="text" name="concepto[]" required></td>
              <td><input type="number" name="cantidad[]" class="cantidad" min="0" step="0.01" required></td>
              <td><input type="number" name="precio[]" class="precio" min="0" step="0.01" required></td>
              <td><button type="button" class="btn btn-danger btn-eliminar">Eliminar</button></td>
            </tr>
          </tbody>
        </table>

        <div class="actions">
          <button type="button" class="btn btn-secondary" id="agregar">+ Agregar producto</button>
        </div>

        <div class="totals">
          Total estimado: <span id="totalVista">$0.00</span>
        </div>
      </div>

      <div class="actions">
        <button class="btn btn-secondary" type="submit" onclick="setDoc('cotizacion','ver')">Ver cotización</button>
        <button class="btn btn-green" type="submit" onclick="setDoc('nota_venta','ver')">Nota de venta</button>
        <button class="btn btn-orange" type="submit" onclick="setDoc('nota_servicio','ver')">Nota de servicio</button>
        <button class="btn btn-primary" type="submit" onclick="setDoc('cotizacion','descargar')">Descargar cotización</button>
                            <button type="submit" name="accion" value="plano">
    Guardar cotización y diseñar plano
</button>
                            <button type="submit" name="accion" value="pdf">
    Guardar y generar PDF
</button>
      </div>
    </form>
  </div>
</div>

<script>
const productosBody = document.getElementById('productosBody');
const btnAgregar = document.getElementById('agregar');

function setDoc(tipo, modo){
  document.getElementById('tipo_documento').value = tipo;
  document.getElementById('modo_pdf').value = modo;
}

function recalcular() {
  let subtotal = 0;

  productosBody.querySelectorAll('tr').forEach(tr => {
    const cantidad = parseFloat(tr.querySelector('.cantidad')?.value || 0);
    const precio = parseFloat(tr.querySelector('.precio')?.value || 0);
    subtotal += cantidad * precio;
  });

  const iva = subtotal * 0.16;
  const total = subtotal + iva;

  document.getElementById('totalVista').innerText =
    '$' + total.toLocaleString('en-US', {minimumFractionDigits:2, maximumFractionDigits:2});
}

btnAgregar.addEventListener('click', () => {
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td><input type="text" name="concepto[]" required></td>
    <td><input type="number" name="cantidad[]" class="cantidad" min="0" step="0.01" required></td>
    <td><input type="number" name="precio[]" class="precio" min="0" step="0.01" required></td>
    <td><button type="button" class="btn btn-danger btn-eliminar">Eliminar</button></td>
  `;
  productosBody.appendChild(tr);
  recalcular();
});

productosBody.addEventListener('input', function(e){
  if (e.target.classList.contains('cantidad') || e.target.classList.contains('precio')) {
    recalcular();
  }
});

productosBody.addEventListener('click', function(e){
  if (e.target.classList.contains('btn-eliminar')) {
    if (productosBody.querySelectorAll('tr').length <= 1) {
      alert('Debe haber al menos un producto.');
      return;
    }
    e.target.closest('tr').remove();
    recalcular();
  }
});

recalcular();
</script>
</body>
</html>
