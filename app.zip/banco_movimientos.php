<?php
require_once __DIR__.'/auth.php';require_once __DIR__.'/app/bancos.php';
ojb_admin();date_default_timezone_set('America/Mexico_City');
$error='';$notice=$_SESSION['ojb_notice']??'';unset($_SESSION['ojb_notice']);
$actor=($_SESSION['usuario_nombre']??'Administrador').' (#'.(int)$_SESSION['usuario_id'].')';
try {
 ojb_schema($pdo);
 if($_SERVER['REQUEST_METHOD']==='POST') {
  require_post_csrf();$action=ojr_text($_POST,'accion',30,true);
  if($action==='importar') {
   $f=$_FILES['correo']??[];
   if(($f['error']??-1)!==UPLOAD_ERR_OK || ($f['size']??0)>1048576 || !is_uploaded_file($f['tmp_name']??''))throw new InvalidArgumentException('Selecciona un correo .eml de hasta 1 MB.');
   $raw=file_get_contents($f['tmp_name']);$mail=ojb_eml($raw);
   $r=ojb_parse($mail['headers']['from']??'',$mail['headers']['subject']??'',$mail['body']);
   $account=ojb_config()['cuenta']??'5679';if($r['cuenta']!==$account)throw new InvalidArgumentException('Este aviso corresponde a otra cuenta.');
   $result=ojb_import($pdo,$r,$mail['headers']['message-id']??hash('sha256',$raw),'eml_manual',$actor);
   $notice=($result['evento_pendiente']??false)?'Evento guardado; se completarán las fechas cuando coincida con un SPEI confirmado.':(($result['actualizado']??false)?'Fechas bancarias actualizadas; clasificación y recibo conservados.':($result['nuevo']?'Aviso importado. Clasifícalo y verifica el movimiento en el banco antes de registrar un cobro.':'Este movimiento ya estaba registrado; no se duplicó.'));
  } elseif(in_array($action,['clasificar','aplicar','vincular'],true)) {
   $mid=(int)($_POST['movimiento_id']??0);$pdo->beginTransaction();
   $q=$pdo->prepare('SELECT * FROM oj_banco_movimientos WHERE id=? FOR UPDATE');$q->execute([$mid]);$r=$q->fetch();
   if(!$r)throw new InvalidArgumentException('Movimiento no encontrado.');
   if($action==='clasificar') {
    $class=ojr_text($_POST,'clasificacion',12,true);if(!in_array($class,['personal','negocio','pendiente'],true))throw new InvalidArgumentException('Clasificación inválida.');
    if($r['recibo_id'] && $class!=='negocio')throw new InvalidArgumentException('El movimiento tiene un recibo asociado. Revisa el recibo antes de cambiar su clasificación.');
    $category=ojr_text($_POST,'categoria',100);$notes=ojr_text($_POST,'notas',1000);
    $q=$pdo->prepare('UPDATE oj_banco_movimientos SET clasificacion=?,categoria=?,notas=?,actualizado_en=?,actualizado_por=? WHERE id=?');
    $q->execute([$class,$category,$notes,date('Y-m-d H:i:s'),$actor,$mid]);
    ojb_audit($pdo,$mid,'clasificacion',['antes'=>[$r['clasificacion'],$r['categoria'],$r['notas']],'despues'=>[$class,$category,$notes]],$actor);$notice='Clasificación guardada.';
   } else {
    $docId=(int)($_POST['documento_id']??0);
    if($action==='vincular'){ojb_link_locked($pdo,$r,$docId,(int)($_POST['recibo_id']??0),$_POST,$_SESSION,$actor);$notice='Recibo existente vinculado. No se agregó otro pago ni se modificó el saldo.';}
    else {ojb_apply_locked($pdo,$r,$docId,$_POST,$_SESSION,$actor);$notice='Pago registrado. El recibo PDF está disponible y el saldo del trabajo se actualizó.';}
   }
   $pdo->commit();
  } else throw new InvalidArgumentException('Acción inválida.');
  $_SESSION['ojb_notice']=$notice;header('Location: banco_movimientos.php'.(!empty($mid)?'?id='.$mid:''));exit;
 }
} catch(PDOException $e) {if($pdo->inTransaction())$pdo->rollBack();error_log('OJ banco panel: '.$e->getMessage());$error='No se pudo guardar. Revisa las tablas de movimientos y recibos; consulta INSTALAR_BANCOS.md.';}
catch(Throwable $e) {if($pdo->inTransaction())$pdo->rollBack();$error=$e->getMessage();}
$selected=null;$docs=[];$audit=[];
try {
 $detail=(int)($_GET['id']??$_POST['movimiento_id']??0);
 if($detail) {
  $q=$pdo->prepare('SELECT m.*,r.folio recibo_folio,r.anulado_en FROM oj_banco_movimientos m LEFT JOIN oj_recibos r ON r.id=m.recibo_id WHERE m.id=?');$q->execute([$detail]);$selected=$q->fetch();
  $q=$pdo->prepare('SELECT * FROM oj_banco_auditoria WHERE movimiento_id=? ORDER BY id DESC LIMIT 50');$q->execute([$detail]);$audit=$q->fetchAll();
 }
 $from=ojr_text($_GET,'desde',10)?:date('Y-m-01');$to=ojr_text($_GET,'hasta',10)?:date('Y-m-d');
 foreach([$from,$to] as $day){$d=DateTimeImmutable::createFromFormat('!Y-m-d',$day);if(!$d || $d->format('Y-m-d')!==$day)throw new InvalidArgumentException('Revisa las fechas del filtro.');}
 if($from>$to)throw new InvalidArgumentException('La fecha inicial debe ser anterior a la final.');
 $class=ojr_text($_GET,'clase',12);if($class && !in_array($class,['personal','negocio','pendiente'],true))throw new InvalidArgumentException('Filtro inválido.');
 $params=[$from.' 00:00:00',$to.' 23:59:59'];$where='fecha BETWEEN ? AND ?';if($class){$where.=' AND clasificacion=?';$params[]=$class;}
 $listWhere=str_replace(['fecha','clasificacion'],['m.fecha','m.clasificacion'],$where);
 $q=$pdo->prepare('SELECT m.*, r.folio recibo_folio, r.anulado_en, d.folio documento_folio, d.cliente_nombre FROM oj_banco_movimientos m LEFT JOIN oj_recibos r ON r.id=m.recibo_id LEFT JOIN cotizaciones d ON d.id=m.documento_id WHERE '.$listWhere.' ORDER BY m.fecha DESC,m.id DESC LIMIT 300');$q->execute($params);$rows=$q->fetchAll();
 $q=$pdo->prepare('SELECT clasificacion,tipo,SUM(importe + IF(tipo="egreso",comision,0)) total,COUNT(*) cantidad FROM oj_banco_movimientos WHERE '.$where.' GROUP BY clasificacion,tipo');$q->execute($params);$totals=$q->fetchAll();
 $pending=(int)$pdo->query("SELECT COUNT(*) FROM oj_banco_movimientos WHERE clasificacion='pendiente'")->fetchColumn();

} catch(Throwable $e) {$error=$error?:'No se pudo consultar. Abre INSTALAR_BANCOS.md y verifica las tablas requeridas.';$rows=[];$totals=[];$pending=0;}
$config=ojb_config();$ready=preg_match('/^[a-f0-9]{64}$/D',(string)($config['secreto']??''));
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Movimientos Banorte — Ojo Jarocho</title><link rel="stylesheet" href="assets/bancos.css"></head><body><main>
<nav><a href="dashboard.php">Panel</a> · <a href="banco_movimientos.php">Movimientos</a> · <a href="recibos_historial.php">Recibos</a> · <a href="banco_conexion.php">Conectar Gmail</a></nav>
<h1>Movimientos Banorte</h1><p>Cuenta mixta · <?=ojr_e($config['correo']??'navaje@gmail.com')?> · terminación <?=ojr_e($config['cuenta']??'5679')?></p>
<?php if($error):?><p class="error"><?=ojr_e($error)?></p><?php endif;?><?php if($notice):?><p class="success"><?=ojr_e($notice)?></p><?php endif;?>
<p class="notice">Lectura automática: <?=$ready?'configurada; revisa también que el activador de Google esté funcionando':'pendiente de configurar'?>. Avisos pendientes de clasificar: <?=$pending?>. Los importes son movimientos capturados por correo, no el saldo bancario ni un reporte fiscal. Las transferencias entre tus propias cuentas deben clasificarse como tales.</p>
<details><summary>Importar aviso .eml manualmente</summary><p>Selecciona el archivo descargado de Gmail. Se lee como aviso; antes de emitir un recibo verifica el depósito en Banorte.</p><form method="post" enctype="multipart/form-data"><?=csrf_field()?><input type="hidden" name="accion" value="importar"><input type="file" name="correo" accept=".eml" required><button>Importar aviso</button></form></details>
<?php if($selected):$r=$selected;?>
<section><h2>Movimiento #<?=(int)$r['id']?></h2><p><strong><?=ojr_money(ojr_centavos($r['importe']))?> · <?=ojr_e($r['tipo'])?></strong> · <?=ojr_e($r['fecha'])?></p><p><?=ojr_e($r['descripcion'])?></p><p>Referencia: <?=ojr_e($r['referencia'])?> · Comisión adicional: <?=ojr_money(ojr_centavos($r['comision']))?> · Fecha de aplicación: <?=ojr_e($r['fecha_aplicacion']??'No incluida')?></p>
<form method="post"><?=csrf_field()?><input type="hidden" name="accion" value="clasificar"><input type="hidden" name="movimiento_id" value="<?=(int)$r['id']?>"><div class="grid"><label>Clasificación<select name="clasificacion"><?php foreach(['pendiente'=>'Pendiente','negocio'=>'Negocio','personal'=>'Personal'] as $k=>$v):?><option value="<?=$k?>" <?=$r['clasificacion']===$k?'selected':''?>><?=$v?></option><?php endforeach;?></select></label><label>Categoría<input name="categoria" maxlength="100" list="categorias" value="<?=ojr_e($r['categoria'])?>"><datalist id="categorias"><option>Materiales</option><option>Proveedor</option><option>Gasolina</option><option>Cobro de trabajo</option><option>Anticipo de presupuesto</option><option>Venta</option><option>Transferencia entre cuentas propias</option><option>Gasto personal</option></datalist></label></div><label>Notas<textarea name="notas" maxlength="1000"><?=ojr_e($r['notas'])?></textarea></label><button>Guardar clasificación</button></form>
<?php if($r['recibo_id']):?><div class="success recibo-acciones"><strong>Recibo <?=ojr_e($r['recibo_folio'])?></strong> · <?=$r['anulado_en']?'ANULADO: revisa el historial del trabajo':'Vigente'?><br><a href="recibo_pdf.php?id=<?=(int)$r['recibo_id']?>" target="_blank" rel="noopener">Ver PDF</a><a href="recibo_pdf.php?id=<?=(int)$r['recibo_id']?>&descargar=1">Descargar recibo</a><a href="anticipos.php?id=<?=(int)$r['documento_id']?>">Ver historial del trabajo</a></div>
<?php elseif($r['tipo']==='ingreso' && $r['clasificacion']==='negocio'):?>
<?php include __DIR__.'/app/banco_cobro_form.php'; ?>
<?php endif;?>
<details><summary>Historial de cambios</summary><?php foreach($audit as $a):?><p><?=ojr_e($a['fecha'].' · '.$a['autor'].' · '.$a['accion'])?><br><small><?=ojr_e($a['detalle'])?></small></p><?php endforeach;?></details></section>
<?php endif;?>
<h2>Consultar movimientos</h2><form method="get" class="grid"><label>Desde<input type="date" name="desde" value="<?=ojr_e($from??date('Y-m-01'))?>" required></label><label>Hasta<input type="date" name="hasta" value="<?=ojr_e($to??date('Y-m-d'))?>" required></label><label>Clasificación<select name="clase"><option value="">Todas</option><?php foreach(['pendiente','negocio','personal'] as $c):?><option value="<?=$c?>" <?=($class??'')===$c?'selected':''?>><?=ucfirst($c)?></option><?php endforeach;?></select></label><button>Consultar</button></form>
<div class="cards"><?php foreach($totals as $total):?><div><?=ojr_e(ucfirst($total['clasificacion']).' · '.$total['tipo'])?><strong><?=ojr_money(ojr_centavos($total['total']))?></strong><small><?=(int)$total['cantidad']?> movimientos</small></div><?php endforeach;?></div>
<p>Consulta por fecha de operación; cuando solo existe el aviso SPEI, se usa la fecha que informa ese aviso. Totales del período, incluyendo comisión en egresos. Lista: hasta 300 movimientos más recientes; reduce el período para ver los anteriores.</p>
<div class="scroll"><table><thead><tr><th>Fecha</th><th>Operación</th><th>Importe</th><th>Comisión</th><th>Clasificación</th><th>Trabajo / recibo</th><th>Acción</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=ojr_e($r['fecha'])?><?php if($r['fecha_aplicacion']):?><br><small>Aplicación: <?=ojr_e($r['fecha_aplicacion'])?></small><?php endif;?></td><td><?=ojr_e($r['descripcion'])?><br><small><?=ojr_e($r['referencia'])?></small></td><td><?=ojr_e($r['tipo'])?><br><?=ojr_money(ojr_centavos($r['importe']))?></td><td><?=ojr_money(ojr_centavos($r['comision']))?></td><td><?=ojr_e(ucfirst($r['clasificacion']).($r['categoria']?' · '.$r['categoria']:''))?></td><td><?php if($r['recibo_id']):?><strong><?=ojr_e($r['documento_folio'])?></strong><br><?=ojr_e($r['cliente_nombre'])?><br><?=ojr_e($r['recibo_folio'])?><?=$r['anulado_en']?' · ANULADO':''?><br><a href="recibo_pdf.php?id=<?=(int)$r['recibo_id']?>" target="_blank" rel="noopener">Ver PDF</a> · <a href="recibo_pdf.php?id=<?=(int)$r['recibo_id']?>&descargar=1">Descargar</a><?php else:?>Sin recibo asociado<?php endif;?></td><td><a href="banco_movimientos.php?id=<?=(int)$r['id']?>">Revisar</a></td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="7">Sin movimientos en este período.</td></tr><?php endif;?></tbody></table></div>
</main><?php if(!$selected):?><script>
let dirty=false;document.querySelectorAll('form').forEach(f=>f.addEventListener('input',()=>dirty=true));
setInterval(()=>{if(!dirty && !document.hidden)location.reload();},60000);
</script><?php endif;?></body></html>
