-- Ejecutar UNA SOLA VEZ en la base jesusna1_cotiza desde phpMyAdmin.
-- Antes de ejecutarlo, realiza un respaldo de la base.
ALTER TABLE solicitudes_servicio
    ADD COLUMN origen VARCHAR(30) NOT NULL DEFAULT 'web' AFTER estado,
    ADD COLUMN producto_nombre VARCHAR(255) NULL AFTER origen,
    ADD COLUMN producto_sku VARCHAR(100) NULL AFTER producto_nombre,
    ADD COLUMN producto_url VARCHAR(500) NULL AFTER producto_sku,
    ADD COLUMN proxima_accion VARCHAR(255) NULL AFTER producto_url,
    ADD COLUMN fecha_seguimiento DATETIME NULL AFTER proxima_accion,
    ADD COLUMN notas_internas TEXT NULL AFTER fecha_seguimiento,
    ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at;

CREATE INDEX idx_solicitudes_seguimiento ON solicitudes_servicio (fecha_seguimiento);
CREATE INDEX idx_solicitudes_origen ON solicitudes_servicio (origen);
