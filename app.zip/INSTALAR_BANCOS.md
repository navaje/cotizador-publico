# Movimientos Banorte en el cotizador de Ojo Jarocho

Esta versión incorpora avisos de compras en comercio, SPEI recibidos y SPEI enviados a otros bancos. Todos entran como Pendiente. Solo el administrador puede abrir movimientos y la conexión porque la cuenta mezcla dinero personal y del negocio.

## 1. Actualizar el cotizador

1. Respalda archivos y base de datos actuales desde cPanel.
2. Extrae el ZIP. Sube el contenido de la carpeta `cotizador` sobre `/public_html/cotizador/`. Si tu instalación actual tiene configuración más reciente, conserva tu `db.php`, `private_config.php` y archivos de configuración existentes. No reemplaces PDFs ni archivos de clientes por copias antiguas: los archivos del módulo que cambiaron se enumeran abajo.
3. En phpMyAdmin selecciona la base actual y ejecuta `MIGRACION_BANCOS.sql`. No elimina ni altera recibos existentes. Si cotizaciones u oj_recibos no usan InnoDB, verifica y cambia su motor antes de aplicar pagos: los cobros requieren transacciones.
4. Entra como administrador y abre Panel → Movimientos Banorte. Este primer acceso crea las dos tablas del módulo. La cuenta configurada es la terminación 5679 que aparece en tus ejemplos; verifica que sea la que deseas monitorear.
5. Importa primero un `.eml` de prueba desde el propio módulo. Reimporta el mismo correo y comprueba que no se duplique.

Archivos nuevos: `app/bancos.php`, `banco_movimientos.php`, `banco_conexion.php`, `banco_receptor.php`, `assets/bancos.css`, carpeta `bancos`, `MIGRACION_BANCOS.sql` e instrucciones. Archivos modificados: `dashboard.php` y `app/recibos.php`. Puedes subir únicamente estos archivos. No subas los correos de ejemplo al sitio.

## 2. Conectar navaje@gmail.com

La lectura se ejecuta en tu propia cuenta Google, con permiso de Gmail de solo lectura. No usa contraseñas bancarias, no mueve dinero y no envía mensajes. Solo remite al cotizador los cuerpos de los tipos de avisos bancarios compatibles, después de revisar su remitente y el resultado DKIM/DMARC de Gmail. No guarda el correo completo en la base, solo sus datos de movimiento.

1. Abre Movimientos → Conectar Gmail y pulsa **Crear clave de conexión**. El servidor guarda `bancos/config.php`. Si la carpeta no permite escribir, copia `config.ejemplo.php` como `config.php` y reemplaza el texto de ejemplo por una clave hexadecimal aleatoria de 64 caracteres, generada en tu servidor con `bin2hex(random_bytes(32))`. No uses una contraseña bancaria como clave.
2. Abre https://script.google.com/ con **navaje@gmail.com** y crea un proyecto llamado `Ojo Jarocho — Avisos Banorte`.
3. Copia el contenido de `bancos/BanorteGmail.gs` en `Código.gs`.
4. En Configuración del proyecto activa **Mostrar el archivo de manifiesto appsscript.json**. Reemplaza el manifiesto por el contenido del archivo incluido `bancos/appsscript.json`. Incluye el servicio avanzado Gmail v1 y permisos de solo lectura, conexión HTTPS y administración de activadores. Si Gmail no aparece en Servicios, agrégalo con el botón +. Si utilizas un proyecto Cloud estándar, también debes habilitar Gmail API en ese proyecto.
5. En Configuración del proyecto → Propiedades de la secuencia de comandos agrega:
   - `OJ_URL`: `https://ojojarocho.online/cotizador/banco_receptor.php`
   - `OJ_SECRETO`: la clave que muestra Conectar Gmail en el cotizador.
6. Selecciona `sincronizarBanorte` y pulsa Ejecutar. Autoriza con navaje@gmail.com. El proyecto solicitará acceso de lectura del correo y conexión con un servicio externo. Si Google muestra una advertencia, comprueba que sea el proyecto que acabas de crear y revisa los permisos antes de continuar.
7. Comprueba los movimientos importados en el cotizador. La primera ejecución busca los últimos 30 días; las siguientes continúan desde la última revisión completa, con 48 horas de solapamiento. El servidor evita duplicados incluso si ya importaste un aviso manualmente.
8. Ejecuta `activarRevisionCadaCincoMinutos` una sola vez. En Activadores debe aparecer exactamente uno para `sincronizarBanorte`. No necesitas publicar el script ni crear una aplicación web en Google. No depende de cron de HostGator.
9. Revisa **Ejecuciones** si hay errores. Un 401 suele indicar clave distinta o firma inválida; un 403, correo o cuenta diferentes; un 422, un formato de correo no compatible; un 503, configuración o acceso a la base de datos. Si recibes 403 del hosting antes de llegar al receptor, consulta el registro de ModSecurity sin desactivar protecciones globalmente.

Los cinco minutos son un intervalo programado, no garantía de entrega instantánea. La llegada del correo, los activadores y las cuotas de Google influyen en el tiempo. La lista se actualiza cada minuto mientras está visible y no has empezado a editar un formulario. Los errores de revisión se reintentan; una interrupción prolongada puede requerir varias ejecuciones para recuperar todos los avisos. Los avisos rechazados por autenticación no se importan automáticamente: verifica esos movimientos en Banorte.

Para pausar ejecuta `desactivarRevision`. Para revocar la conexión elimina el activador y revoca la autorización del proyecto desde tu cuenta Google. Si compartes la clave accidentalmente, cámbiala en config.php y OJ_SECRETO.

## 3. Clasificar y registrar cobros

- **Personal:** compras o entradas ajenas al negocio.
- **Negocio:** movimientos de Ojo Jarocho. Puedes agregar una categoría y notas.
- **Pendiente:** aún no conoces su origen o finalidad.
- Las transferencias entre tus propias cuentas deben llevar esa categoría; no son ventas por el hecho de entrar a la cuenta. Los totales muestran flujo bancario capturado, no utilidad, ingreso fiscal ni saldo disponible.

Abre un depósito, clasifícalo como Negocio y selecciona el documento al que corresponde. La sugerencia muestra el ID, folio, cliente y total; para documentos antiguos usa el ID visible en la URL del documento. Escribe quién transfirió, confirma que revisaste el abono en Banorte y los pagos anteriores, y pulsa Registrar pago y actualizar saldo. Se reutiliza el módulo de recibos: crea anticipo, abono o liquidación y actualiza los documentos relacionados. El registro del recibo y la vinculación bancaria se guardan en la misma transacción.

El aviso de SPEI recibido que proporcionaste no incluye cliente ni concepto: no se identifica automáticamente al pagador. El movimiento se asigna manualmente y no se emite un recibo solo por recibir un correo. La compra guarda por separado la fecha de operación y la de aplicación. En SPEI enviado, el monto y la comisión se guardan separados; los totales de egresos suman ambos.

Esta primera versión aplica el depósito completo a un trabajo. Si debe distribuirse entre varios documentos, registra los pagos en Recibos y deja una nota en el movimiento sin volver a aplicarlo. Para pagos ya registrados usa una nota de conciliación, no un recibo nuevo. Un recibo anulado se muestra como tal y el aviso conserva el vínculo original; cualquier corrección se hace desde el historial de recibos, sin borrar la trazabilidad.

No incluye aún retiros, depósitos de efectivo ni otros tipos de avisos sin ejemplo. Puede que algunas operaciones no generen correo. Compara periódicamente con los movimientos o estados de cuenta de Banorte para completar y verificar el registro.

## 4. Verificación antes de usar en producción

- Importar compra, SPEI recibido y SPEI enviado, cotejando importe, fecha y referencia.
- Volver a importar el mismo aviso: no aumenta el conteo.
- Clasificar un gasto como Personal y otro como Negocio; filtrar por cada clasificación.
- Aplicar un depósito de prueba a un documento de prueba: se genera un solo recibo y cambia el saldo.
- Reintentar aplicar el mismo depósito: no se genera otro recibo.
- Comprobar que un usuario sin rol administrador no abre Movimientos ni Conectar Gmail.
- Comprobar que `/cotizador/bancos/config.php` y los archivos de esa carpeta responden 403 desde el navegador, incluso sin iniciar sesión. Esta protección requiere Apache con .htaccess activo, como el hosting actual.

La validación local y sus límites se documentan en VERIFICACION_BANCOS.txt. La autorización de Gmail y la prueba con la base real se realizan en tu instalación; este paquete no instala ni autoriza conexiones por sí solo.

Referencias de implementación:
https://developers.google.com/apps-script/advanced/gmail
https://developers.google.com/apps-script/reference/url-fetch/url-fetch-app
https://developers.google.com/apps-script/reference/utilities/utilities
https://developers.google.com/apps-script/reference/script/clock-trigger-builder
