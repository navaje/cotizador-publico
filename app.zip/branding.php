<?php

return [
    'nombre' => 'Ojo Jarocho',
    'lema' => 'La mirada que cuida Veracruz',
    'telefono' => '+52 999 918 5208',
    'whatsapp' => '529999185208',
    'email' => 'ventas@ojojarocho.online',
    'web' => 'https://ojojarocho.online',
    'catalogo' => 'https://www.productos-info.com/tienda/ojojarocho',
    'logo' => 'assets/logo.png',
];
