<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_post_csrf();

if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    die('ID inválido');
}

$id = (int) $_POST['id'];
$estado = $_POST['estado'] ?? '';

if (!in_array($estado, ['pendiente', 'anticipo', 'pagado'], true)) {
    die('Estado inválido');
}

// Los estados de un trabajo con recibos se derivan de sus pagos.
require_once __DIR__ . '/app/recibos.php';
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
try {
    $chain = ojr_cadena($pdo, $id);
    $rootId = (int)end($chain)['id'];
    ojr_verificar_motor($pdo);
    $pdo->beginTransaction();
    $lock = $pdo->prepare('SELECT id FROM cotizaciones WHERE id = ? FOR UPDATE');
    $lock->execute([$rootId]);
    if (ojr_historial($pdo, $rootId)) {
        $pdo->rollBack();
        http_response_code(409);
        exit('Este trabajo tiene recibos. No se puede cambiar su estado manualmente; registra o anula el pago desde Recibos / Anticipos.');
    }
} catch (Throwable $error) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('OJ control de recibos: '.$error->getMessage());
    http_response_code(503);
    exit('Revisa la instalación del módulo: ejecuta MIGRACION_RECIBOS.sql antes de operar con documentos.');
}

$stmt = $pdo->prepare("
    UPDATE cotizaciones
    SET estado_pago = :estado
    WHERE id = :id
");
$stmt->execute([
    ':estado' => $estado,
    ':id' => $id
]);

$pdo->commit();

header('Location: dashboard.php');
exit;
