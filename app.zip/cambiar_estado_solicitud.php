<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_post_csrf();

if (!isset($_POST['id']) || !is_numeric($_POST['id'])) {
    die('ID inválido');
}

$id = (int) $_POST['id'];
$estado = $_POST['estado'] ?? '';

$estadosValidos = ['nuevo', 'contactado', 'visita_programada', 'cotizado', 'aceptado', 'atendido', 'perdido'];

if (!in_array($estado, $estadosValidos, true)) {
    die('Estado inválido');
}

$stmt = $pdo->prepare("
    UPDATE solicitudes_servicio
    SET estado = :estado
    WHERE id = :id
");
$stmt->execute([
    ':estado' => $estado,
    ':id' => $id
]);

header('Location: ver_solicitud.php?id=' . $id);
exit;
