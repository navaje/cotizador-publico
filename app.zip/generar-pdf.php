<?php
   

require_once __DIR__ . '/auth.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Acceso directo bloqueado');
}
require_post_csrf();

// Los errores detallados se registran, pero no se muestran a visitantes.
ini_set('display_errors', '0');
ini_set('log_errors', '1');

require_once __DIR__ . '/dompdf/autoload.inc.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/folios.php';

use Dompdf\Dompdf;
use Dompdf\Options;

function money($n) {
    return '$' . number_format((float)$n, 2, '.', ',');
}

function e($text) {
    return htmlspecialchars((string)$text, ENT_QUOTES, 'UTF-8');
}

// EMPRESA
$stmtEmpresa = $pdo->query("SELECT * FROM empresa LIMIT 1");
$empresa = $stmtEmpresa->fetch();

if (!$empresa) {
    die('No hay datos configurados en la tabla empresa.');
}

// TIPO DE DOCUMENTO
$tipoDocumento = $_POST['tipo_documento'] ?? 'cotizacion';
$solicitud_id = null;

if (isset($_POST['solicitud_id']) && is_numeric($_POST['solicitud_id'])) {
    $solicitud_id = (int)$_POST['solicitud_id'];
}
if (!in_array($tipoDocumento, ['cotizacion', 'nota_venta', 'nota_servicio'], true)) {
    $tipoDocumento = 'cotizacion';
}

// DATOS DEL FORMULARIO
$cliente_nombre    = trim($_POST['cliente_nombre'] ?? '');
$cliente_telefono  = trim($_POST['cliente_telefono'] ?? '');
$cliente_email     = trim($_POST['cliente_email'] ?? '');
$cliente_direccion = trim($_POST['cliente_direccion'] ?? '');
$proyecto          = trim($_POST['proyecto'] ?? '');

$vigencia           = trim($_POST['vigencia'] ?? '15 días');
$metodo_pago        = trim($_POST['metodo_pago'] ?? '');
$tiempo_instalacion = trim($_POST['tiempo_instalacion'] ?? '');
$descripcion        = trim($_POST['descripcion'] ?? '');
$observaciones      = trim($_POST['observaciones'] ?? '');
$condiciones        = trim($_POST['condiciones'] ?? '');

$conceptos  = $_POST['concepto'] ?? [];
$cantidades = $_POST['cantidad'] ?? [];
$precios    = $_POST['precio'] ?? [];

// ARMAR FILAS Y TOTALES
$rows = '';
$subtotal = 0;

for ($i = 0; $i < count($conceptos); $i++) {
    $concepto = trim($conceptos[$i] ?? '');
    $cantidad = (float)($cantidades[$i] ?? 0);
    $precio   = (float)($precios[$i] ?? 0);

    if ($concepto === '' || $cantidad <= 0 || $precio < 0) {
        continue;
    }

    $importe = $cantidad * $precio;
    $subtotal += $importe;

    $rows .= '
    <tr>
      <td>' . e($concepto) . '</td>
      <td class="center">' . rtrim(rtrim(number_format($cantidad, 2, '.', ''), '0'), '.') . '</td>
      <td class="right">' . money($precio) . '</td>
      <td class="right">' . money($importe) . '</td>
    </tr>';
}

if ($rows === '') {
    $rows = '
    <tr>
      <td colspan="4" class="center">No se capturaron conceptos válidos.</td>
    </tr>';
}

$iva = $subtotal * 0.16;
$total = $subtotal + $iva;

// FOLIO PROFESIONAL
$folio = generarFolio($pdo, $tipoDocumento);
$fecha = date('d/m/Y');

// ESTADO INICIAL
$estadoPago = 'pendiente';
if ($tipoDocumento === 'cotizacion') {
    $estadoPago = 'pendiente';
}

// GUARDAR DOCUMENTO EN BD
$stmt = $pdo->prepare("
INSERT INTO cotizaciones (
    folio, fecha,
    empresa_nombre, empresa_telefono, empresa_email, empresa_web, empresa_direccion,
    cliente_nombre, cliente_telefono, cliente_email, cliente_direccion,
    proyecto, vigencia, metodo_pago, tiempo_instalacion,
    descripcion, observaciones, condiciones,
    subtotal, iva, total,
tipo_documento, estado_pago, solicitud_id
) VALUES (
    :folio, NOW(),
    :empresa_nombre, :empresa_telefono, :empresa_email, :empresa_web, :empresa_direccion,
    :cliente_nombre, :cliente_telefono, :cliente_email, :cliente_direccion,
    :proyecto, :vigencia, :metodo_pago, :tiempo_instalacion,
    :descripcion, :observaciones, :condiciones,
    :subtotal, :iva, :total,
:tipo_documento, :estado_pago, :solicitud_id
)");

$stmt->execute([
    ':folio' => $folio,
    ':empresa_nombre' => $empresa['nombre'],
    ':empresa_telefono' => $empresa['telefono'],
    ':empresa_email' => $empresa['email'],
    ':empresa_web' => $empresa['web'],
    ':empresa_direccion' => $empresa['direccion'],
    ':cliente_nombre' => $cliente_nombre,
    ':cliente_telefono' => $cliente_telefono,
    ':cliente_email' => $cliente_email,
    ':cliente_direccion' => $cliente_direccion,
    ':proyecto' => $proyecto,
    ':vigencia' => $vigencia,
    ':metodo_pago' => $metodo_pago,
    ':tiempo_instalacion' => $tiempo_instalacion,
    ':descripcion' => $descripcion,
    ':observaciones' => $observaciones,
    ':condiciones' => $condiciones,
    ':subtotal' => $subtotal,
    ':iva' => $iva,
    ':total' => $total,
    ':tipo_documento' => $tipoDocumento,
    ':estado_pago' => $estadoPago,
    ':solicitud_id' => $solicitud_id
]);

$cotizacion_id = $pdo->lastInsertId();
             $planoRuta = __DIR__ . '/plano/planos/plano_' . $cotizacion_id . '.png';
$planoHtml = '';

if (file_exists($planoRuta)) {
    $planoData = base64_encode(file_get_contents($planoRuta));
    $planoHtml = '
    <div style="page-break-before: always;">
        <div class="section-title">Plano de instalación</div>
        <img src="data:image/png;base64,' . $planoData . '" style="width:100%;">
    </div>';
}

// GUARDAR ITEMS
$stmtItem = $pdo->prepare("
INSERT INTO cotizacion_items (
    cotizacion_id, concepto, cantidad, precio, importe
) VALUES (
    :cotizacion_id, :concepto, :cantidad, :precio, :importe
)");

for ($i = 0; $i < count($conceptos); $i++) {
    $concepto = trim($conceptos[$i] ?? '');
    $cantidad = (float)($cantidades[$i] ?? 0);
    $precio   = (float)($precios[$i] ?? 0);

    if ($concepto === '' || $cantidad <= 0 || $precio < 0) {
        continue;
    }

    $importe = $cantidad * $precio;

    $stmtItem->execute([
        ':cotizacion_id' => $cotizacion_id,
        ':concepto' => $concepto,
        ':cantidad' => $cantidad,
        ':precio' => $precio,
        ':importe' => $importe
    ]);
}
if ($solicitud_id) {
    $nuevoEstadoSolicitud = 'cotizado';

    if ($tipoDocumento === 'nota_venta' || $tipoDocumento === 'nota_servicio') {
        $nuevoEstadoSolicitud = 'aceptado';
    }

    $stmtSol = $pdo->prepare("
        UPDATE solicitudes_servicio
        SET estado = :estado
        WHERE id = :id
    ");
    $stmtSol->execute([
        ':estado' => $nuevoEstadoSolicitud,
        ':id' => $solicitud_id
    ]);
}

// TÍTULO Y COLOR SEGÚN TIPO
$nombreDocumento = 'Cotización';
$subtituloDocumento = 'Cotización de equipo / instalación';
$color = '#0d3b66';

if ($tipoDocumento === 'nota_venta') {
    $nombreDocumento = 'NOTA DE VENTA';
    $subtituloDocumento = 'Documento de venta';
    $color = '#15803d';
} elseif ($tipoDocumento === 'nota_servicio') {
    $nombreDocumento = 'NOTA DE SERVICIO';
    $subtituloDocumento = 'Documento de servicio';
    $color = '#c2410c';
}

// LOGO
$logoPath = __DIR__ . '/' . ($empresa['logo'] ?? 'assets/logo.png');
$logoHtml = '';

if (file_exists($logoPath)) {
    $extension = strtolower(pathinfo($logoPath, PATHINFO_EXTENSION));
    $mime = 'image/png';

    if ($extension === 'jpg' || $extension === 'jpeg') {
        $mime = 'image/jpeg';
    } elseif ($extension === 'webp') {
        $mime = 'image/webp';
    }

    $logoData = base64_encode(file_get_contents($logoPath));
    $logoHtml = '<img src="data:' . $mime . ';base64,' . $logoData . '" style="height:52px; margin-bottom:7px;">';
}

$modo_pdf = $_POST['modo_pdf'] ?? 'ver';
$descargar = ($modo_pdf === 'descargar');

$options = new Options();
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);

$html = '
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<style>
  @page {
    margin: 28px 28px 34px 28px;
  }

  body{
    font-family: DejaVu Sans, sans-serif;
    font-size: 11px;
    color: #1f2937;
    margin: 0;
  }

  .header{
    width: 100%;
    border-bottom: 3px solid ' . $color . ';
    padding-bottom: 12px;
    margin-bottom: 18px;
  }

  .header-table{
    width: 100%;
    border-collapse: collapse;
  }

  .header-table td{
    border: none;
    vertical-align: top;
  }

  .brand{
    font-size: 14px;
    font-weight: bold;
    color: ' . $color . ';
    margin-bottom: 4px;
  }

  .docname{
    font-size: 18px;
    font-weight: bold;
    color: ' . $color . ';
    margin-top: 10px;
    line-height: 1.1;
  }

  .subtitle{
    font-size: 13px;
    color: #4b5563;
    margin-top: 4px;
  }

  .folio-box{
    text-align: right;
    font-size: 11px;
    vertical-align: top;
    padding-top: 10px;
  }

  .folio-number{
    background: ' . $color . ';
    color: #fff;
    display: inline-block;
    padding: 8px 12px;
    border-radius: 6px;
    font-weight: bold;
    margin-bottom: 8px;
  }

  .section-title{
    font-size: 13px;
    font-weight: bold;
    color: ' . $color . ';
    margin: 16px 0 8px;
    padding-bottom: 4px;
    border-bottom: 1px solid #dbe3ec;
  }

  .info-box{
    background: #f8fafc;
    border: 1px solid #d6dee8;
    border-radius: 8px;
    padding: 12px;
    margin-bottom: 12px;
  }

  .info-table{
    width: 100%;
    border-collapse: collapse;
  }

  .info-table td{
    border: none;
    padding: 4px 6px 4px 0;
    vertical-align: top;
  }

  .label{
    font-weight: bold;
    color: #111827;
    width: 130px;
  }

  table.products{
    width: 100%;
    border-collapse: collapse;
    margin-top: 8px;
  }

  .products th{
    background: ' . $color . ';
    color: #fff;
    font-size: 11px;
    padding: 10px 8px;
    text-align: left;
  }

  .products td{
    border: 1px solid #d9e2ec;
    padding: 8px;
    font-size: 11px;
  }

  .center{
    text-align: center;
  }

  .right{
    text-align: right;
  }

  .totals{
    width: 280px;
    margin-left: auto;
    margin-top: 18px;
    border-collapse: collapse;
    border-radius: 8px;
    overflow: hidden;
  }

  .totals td{
    border: 1px solid #d6dee8;
    padding: 9px 10px;
    font-size: 11px;
  }

  .totals .grand td{
    background: ' . $color . ';
    color: #fff;
    font-weight: bold;
    font-size: 13px;
  }

  .two-col{
    width: 100%;
    border-collapse: collapse;
    margin-top: 18px;
  }

  .two-col td{
    width: 50%;
    vertical-align: top;
    border: none;
    padding-right: 10px;
  }

  .mini-box{
    background: #fafbfd;
    border: 1px solid #dbe3ec;
    border-radius: 8px;
    padding: 10px;
    min-height: 90px;
  }

  .footer{
    margin-top: 22px;
    padding-top: 10px;
    border-top: 1px solid #dbe3ec;
    font-size: 10px;
    color: #4b5563;
  }
</style>
</head>
<body>

<div class="header">
  <table class="header-table">
    <tr>
      <td style="width:60%;">
        ' . $logoHtml . '
        <div class="brand">' . e($empresa['nombre']) . '</div>
        <div class="docname">' . e($nombreDocumento) . '</div>
        <div class="subtitle">' . e($subtituloDocumento) . '</div>
        <div style="margin-top:8px;">
          ' . e($empresa['direccion']) . '<br>
          ' . e($empresa['telefono']) . ' | ' . e($empresa['email']) . '<br>
          ' . e($empresa['web']) . '
        </div>
      </td>
      <td style="width:40%;" class="folio-box">
        <div class="folio-number">Folio: ' . e($folio) . '</div><br>
        <strong>Fecha:</strong> ' . e($fecha) . '<br>
        <strong>Vigencia:</strong> ' . e($vigencia) . '<br>
        <strong>Pago:</strong> ' . e($metodo_pago) . '<br>
        <strong>Estado:</strong> ' . strtoupper(e($estadoPago)) . '
      </td>
    </tr>
  </table>
</div>

<div class="section-title">Datos del cliente</div>
<div class="info-box">
  <table class="info-table">
    <tr>
      <td class="label">Cliente:</td>
      <td>' . e($cliente_nombre) . '</td>
      <td class="label">Proyecto:</td>
      <td>' . e($proyecto) . '</td>
    </tr>
    <tr>
      <td class="label">Teléfono:</td>
      <td>' . e($cliente_telefono) . '</td>
      <td class="label">Correo:</td>
      <td>' . e($cliente_email) . '</td>
    </tr>
    <tr>
      <td class="label">Ubicación:</td>
      <td colspan="3">' . nl2br(e($cliente_direccion)) . '</td>
    </tr>
  </table>
</div>

<div class="section-title">Descripción general</div>
<div class="info-box">
  ' . nl2br(e($descripcion)) . '
</div>

<div class="section-title">Conceptos cotizados</div>
<table class="products">
  <thead>
    <tr>
      <th style="width:50%;">Concepto</th>
      <th style="width:12%;">Cantidad</th>
      <th style="width:18%;">Precio Unitario</th>
      <th style="width:20%;">Importe</th>
    </tr>
  </thead>
  <tbody>
    ' . $rows . '
  </tbody>
</table>

<table class="totals">
  <tr>
    <td><strong>Subtotal</strong></td>
    <td class="right">' . money($subtotal) . '</td>
  </tr>
  <tr>
    <td><strong>IVA (16%)</strong></td>
    <td class="right">' . money($iva) . '</td>
  </tr>
  <tr class="grand">
    <td><strong>Total</strong></td>
    <td class="right">' . money($total) . '</td>
  </tr>
</table>

<table class="two-col">
  <tr>
    <td>
      <div class="section-title">Instalación y observaciones</div>
      <div class="mini-box">
        <strong>Tiempo estimado:</strong> ' . e($tiempo_instalacion) . '<br><br>
        ' . nl2br(e($observaciones)) . '
      </div>
    </td>
    <td>
      <div class="section-title">Condiciones</div>
      <div class="mini-box">
        ' . nl2br(e($condiciones)) . '
      </div>
    </td>
  </tr>
</table>
              ' . $planoHtml . '
<div class="footer">
  Gracias por considerar a <strong>' . e($empresa['nombre']) . '</strong>.<br>
  Para cualquier aclaración o confirmación, contáctanos al ' . e($empresa['telefono']) . ' o por correo a ' . e($empresa['email']) . '.
</div>

</body>
</html>
';

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$pdfOutput = $dompdf->output();

// NOMBRE DE ARCHIVO SEGURO
$nombreArchivo = preg_replace('/[^A-Za-z0-9\\-_]/', '_', $folio) . '.pdf';
$carpetaPdfs = __DIR__ . '/pdfs';

if (!is_dir($carpetaPdfs)) {
    if (!mkdir($carpetaPdfs, 0775, true) && !is_dir($carpetaPdfs)) {
        die('No se pudo crear la carpeta: ' . $carpetaPdfs);
    }
}

$rutaArchivo = $carpetaPdfs . '/' . $nombreArchivo;
$resultadoGuardado = file_put_contents($rutaArchivo, $pdfOutput);

if ($resultadoGuardado === false) {
    die('No se pudo guardar el PDF en: ' . $rutaArchivo);
}

// Si el usuario pidió diseñar plano, redirige al plano
if (isset($_POST['accion']) && $_POST['accion'] === 'plano') {
    header("Location: plano/?id=" . $cotizacion_id);
    exit;
}

// Si no, muestra o descarga el PDF normal
$dompdf->stream($nombreArchivo, ['Attachment' => $descargar]);
