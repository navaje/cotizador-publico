<?php

// Mantén este archivo privado. Se utiliza para firmar enlaces temporales de PDF.
define('OJ_LINK_SECRET', 'OJ-2026-8f3d1c7a9e54b026d861f0a43c2e759b');
