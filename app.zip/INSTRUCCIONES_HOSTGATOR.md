# Actualización del cotizador de Ojo Jarocho

## Antes de reemplazar archivos

1. En el Administrador de archivos, comprime la carpeta actual `cotizador` como respaldo.
2. En phpMyAdmin, exporta la base de datos utilizada por el cotizador.
3. Cambia la contraseña del usuario administrador: la versión anterior incluía un archivo de prueba con la contraseña temporal.

## Carpetas que debes conservar

No borres ni reemplaces el contenido existente de:

- `pdfs/`
- `plano/planos/`

El ZIP actualizado contiene solamente los archivos de protección `.htaccess` para esas carpetas. Conserva los PDF y planos existentes.

## Instalación

1. Sube el ZIP dentro de `public_html`.
2. Extrae el contenido.
3. Copia los archivos de la carpeta `cotizador` sobre la carpeta actual del mismo nombre.
4. Conserva el `db.php` que ya funciona en el alojamiento. El ZIP incluye la copia original, pero no necesitas cambiar sus credenciales.
5. Verifica que `assets/logo.png` haya sido reemplazado por el logotipo de Ojo Jarocho.
6. En phpMyAdmin, selecciona la base de datos del cotizador y ejecuta `ACTUALIZAR_EMPRESA.sql`.
7. Elimina del servidor `crear_hash.php`, `index1.php`, `testpdf.php`, `dompdf-3.1.5.zip` y cualquier ZIP de respaldo cuando termines.

## Ampliación de seguimiento comercial

Si la tabla `solicitudes_servicio` ya existe y funciona, no vuelvas a ejecutar todo `ACTUALIZAR_EMPRESA.sql`.

1. Selecciona la base `jesusna1_cotiza` en phpMyAdmin.
2. Ejecuta una sola vez `MIGRACION_SEGUIMIENTO.sql`.
3. Después sube los PHP actualizados, incluido `actualizar_seguimiento.php`.
4. Abre una solicitud, guarda una próxima acción y comprueba que aparezca en `solicitudes.php`.

El formulario público también acepta enlaces desde el catálogo mediante estos parámetros:

`solicitud_servicio.php?origen=catalogo&producto=NOMBRE&sku=CLAVE&producto_url=URL`

La URL del producto únicamente se conserva si pertenece a `https://www.productos-info.com/tienda/ojojarocho`.

## Comprobaciones

1. Abre `/cotizador/login.php` e inicia sesión.
2. Comprueba dashboard, listado, solicitudes y configuración de empresa.
3. Crea una cotización de prueba.
4. Genera su PDF y abre WhatsApp.
5. Confirma que el mensaje muestre Ojo Jarocho y que el enlace temporal abra el PDF.
6. Guarda un plano y confirma que solamente puede verse con la sesión iniciada.

## Importante

- Los enlaces de PDF enviados por WhatsApp vencen después de siete días.
- No compartas `private_config.php` ni `db.php`.
- Si el servidor muestra un error relacionado con la directiva `Header` de `.htaccess`, comenta únicamente las tres líneas `Header always set`; mantén `Options -Indexes` y las reglas de bloqueo.
