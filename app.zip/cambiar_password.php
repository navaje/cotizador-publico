<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/app/usuarios.php';

$mensaje = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_post_csrf();

    $actual = (string)($_POST['password_actual'] ?? '');
    $nueva = (string)($_POST['password_nueva'] ?? '');
    $confirmacion = (string)($_POST['password_confirmacion'] ?? '');

    $stmt = $pdo->prepare('SELECT password_hash FROM usuarios WHERE id = ? AND activo = 1 LIMIT 1');
    $stmt->execute([(int)$_SESSION['usuario_id']]);
    $usuario = $stmt->fetch();

    if (!$usuario || !password_verify($actual, $usuario['password_hash'])) {
        $error = 'La contraseña actual no es correcta.';
    } elseif (strlen($nueva) < 12 || strlen($nueva) > 72) {
        $error = 'La nueva contraseña debe tener entre 12 y 72 bytes.';
    } elseif ($nueva !== $confirmacion) {
        $error = 'La confirmación no coincide.';
    } else {
        try {
            $pdo->beginTransaction();
            $lock = $pdo->prepare('SELECT password_hash FROM usuarios WHERE id=? AND activo=1 FOR UPDATE');
            $lock->execute([(int)$_SESSION['usuario_id']]);
            $currentHash = $lock->fetchColumn();
            if (!$currentHash || !password_verify($actual, $currentHash)) throw new RuntimeException('El acceso cambió.');
            $nuevoHash = password_hash($nueva, PASSWORD_DEFAULT);
            $update = $pdo->prepare('UPDATE usuarios SET password_hash = ? WHERE id = ?');
            $update->execute([$nuevoHash, (int)$_SESSION['usuario_id']]);
            // Antes de instalar el panel no existen enlaces de recuperación.
            $exists = $pdo->query("SHOW TABLES LIKE 'oj_password_tokens'")->fetchColumn();
            if ($exists) oj_invalidate_tokens($pdo, (int)$_SESSION['usuario_id']);
            $pdo->commit();
            $_SESSION['usuario_password_fingerprint'] = hash('sha256', $nuevoHash);
            session_regenerate_id(true);
            $mensaje = 'Contraseña actualizada correctamente.';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = 'No se pudo cambiar la contraseña. Recarga la página e inténtalo nuevamente.';
            error_log('OJ cambiar contraseña: '.$e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cambiar contraseña - Ojo Jarocho</title>
<style>
body{font-family:Arial,sans-serif;background:#eef3f8;margin:0;padding:24px;color:#1f2937}
.box{max-width:520px;margin:40px auto;background:#fff;padding:28px;border-radius:14px;box-shadow:0 10px 30px rgba(0,0,0,.08)}
h1{color:#0d3b66;margin-top:0}label{display:block;font-weight:bold;margin:14px 0 6px}
input{width:100%;padding:11px;border:1px solid #cfd8e3;border-radius:8px;box-sizing:border-box}
.actions{display:flex;gap:10px;margin-top:20px}.btn{border:0;border-radius:8px;padding:11px 15px;background:#0d3b66;color:#fff;text-decoration:none;font-weight:bold;cursor:pointer}
.secondary{background:#dbe7f3;color:#0d3b66}.ok{color:#15803d}.bad{color:#b91c1c}
</style>
</head>
<body><div class="box">
<h1>Cambiar contraseña</h1>
<?php if ($mensaje): ?><p class="ok"><?php echo htmlspecialchars($mensaje); ?></p><?php endif; ?>
<?php if ($error): ?><p class="bad"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
<form method="post">
<?php echo csrf_field(); ?>
<label>Contraseña actual</label><input type="password" name="password_actual" required autocomplete="current-password">
<label>Nueva contraseña</label><input type="password" name="password_nueva" required minlength="12" maxlength="72" autocomplete="new-password">
<label>Confirmar nueva contraseña</label><input type="password" name="password_confirmacion" required minlength="12" maxlength="72" autocomplete="new-password">
<div class="actions"><button class="btn" type="submit">Actualizar</button><a class="btn secondary" href="dashboard.php">Volver</a></div>
</form></div></body></html>
