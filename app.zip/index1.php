<?php
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cotizador Ojo Jarocho</title>
  <style>
    *{box-sizing:border-box}
    body{
      margin:0;
      font-family:Arial, Helvetica, sans-serif;
      background:#eef3f8;
      color:#1f2937;
      padding:24px;
    }
    .wrap{
      max-width:1100px;
      margin:0 auto;
      background:#fff;
      border-radius:14px;
      box-shadow:0 10px 30px rgba(0,0,0,.08);
      overflow:hidden;
    }
    .topbar{
      background:#0d3b66;
      color:#fff;
      padding:22px 28px;
    }
    .topbar h1{
      margin:0;
      font-size:28px;
    }
    .topbar p{
      margin:6px 0 0;
      opacity:.9;
    }
    .content{
      padding:28px;
    }
    h2{
      margin:0 0 16px;
      color:#0d3b66;
      font-size:20px;
    }
    .section{
      margin-bottom:28px;
      padding:22px;
      border:1px solid #e5e7eb;
      border-radius:12px;
      background:#fafcff;
    }
    .grid{
      display:grid;
      grid-template-columns:repeat(2, 1fr);
      gap:16px;
    }
    .grid-3{
      display:grid;
      grid-template-columns:repeat(3, 1fr);
      gap:16px;
    }
    .full{
      grid-column:1 / -1;
    }
    label{
      display:block;
      font-weight:700;
      margin-bottom:6px;
      font-size:14px;
    }
    input, textarea, select{
      width:100%;
      padding:12px;
      border:1px solid #cfd8e3;
      border-radius:8px;
      font-size:14px;
      background:#fff;
    }
    textarea{
      resize:vertical;
      min-height:90px;
    }
    table{
      width:100%;
      border-collapse:collapse;
      margin-top:12px;
      background:#fff;
      border-radius:10px;
      overflow:hidden;
    }
    thead th{
      background:#0d3b66;
      color:#fff;
      padding:12px 10px;
      font-size:13px;
      text-align:left;
    }
    tbody td{
      border:1px solid #e5e7eb;
      padding:10px;
      vertical-align:middle;
    }
    tbody td input{
      margin:0;
    }
    .actions{
      display:flex;
      gap:10px;
      flex-wrap:wrap;
      margin-top:14px;
    }
    .btn{
      border:none;
      padding:12px 16px;
      border-radius:8px;
      font-weight:700;
      cursor:pointer;
      font-size:14px;
    }
    .btn-primary{
      background:#0d3b66;
      color:#fff;
    }
    .btn-secondary{
      background:#dbe7f3;
      color:#0d3b66;
    }
    .btn-danger{
      background:#fce7e7;
      color:#b91c1c;
    }
    .summary{
      display:grid;
      grid-template-columns:1fr 320px;
      gap:20px;
      align-items:start;
    }
    .totals{
      border:1px solid #d7e0ea;
      border-radius:12px;
      overflow:hidden;
      background:#fff;
    }
    .totals .row{
      display:flex;
      justify-content:space-between;
      padding:12px 14px;
      border-bottom:1px solid #e5e7eb;
    }
    .totals .row:last-child{
      border-bottom:none;
    }
    .totals .grand{
      background:#0d3b66;
      color:#fff;
      font-size:18px;
      font-weight:700;
    }
    .note{
      font-size:13px;
      color:#6b7280;
      margin-top:8px;
    }

    @media (max-width: 900px){
      .grid,.grid-3,.summary{
        grid-template-columns:1fr;
      }
      body{
        padding:12px;
      }
      .content{
        padding:16px;
      }
      table{
        display:block;
        overflow:auto;
      }
    }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="topbar">
      <h1>Cotizador Ojo Jarocho PRUEBA 999</h1>
      <p>Genera cotizaciones en PDF de forma rápida</p>
    </div>

    <div class="content">
      <form method="POST" action="generar-pdf.php" id="cotizadorForm">
        <input type="hidden" name="modo_pdf" id="modo_pdf" value="ver">

        
            <div>
              <label>Teléfono / WhatsApp</label>
              <input type="text" name="empresa_telefono" value="999 424 7404">
            </div>
            <div>
              <label>Correo</label>
              <input type="email" name="empresa_email" value="ventas@ojojarocho.online">
            </div>
            <div>
              <label>Sitio web</label>
              <input type="text" name="empresa_web" value="ojojarocho.online">
            </div>
            <div class="full">
              <label>Dirección o texto corto de contacto</label>
              <input type="text" name="empresa_direccion" value="Cond. Pan #55, Geovillas del puerto, Veracruz, Ver.">
            </div>
          </div>
        </div>

        <div class="section">
          <h2>Datos del cliente</h2>
          <div class="grid">
            <div>
              <label>Nombre del cliente</label>
              <input type="text" name="cliente_nombre" required>
            </div>
            <div>
              <label>Teléfono</label>
              <input type="text" name="cliente_telefono">
            </div>
            <div>
              <label>Correo</label>
              <input type="email" name="cliente_email">
            </div>
            <div>
              <label>Proyecto</label>
              <input type="text" name="proyecto">
            </div>
            <div class="full">
              <label>Domicilio / ubicación de instalación</label>
              <textarea name="cliente_direccion"></textarea>
            </div>
          </div>
        </div>

        <div class="section">
          <h2>Detalles de la cotización</h2>
          <div class="grid-3">
            <div>
              <label>Vigencia</label>
              <input type="text" name="vigencia" value="15 días">
            </div>
            <div>
              <label>Método de pago</label>
              <input type="text" name="metodo_pago" value="Transferencia / Efectivo">
            </div>
            <div>
              <label>Tiempo de instalación</label>
              <input type="text" name="tiempo_instalacion" value="Sujeto a agenda y confirmación">
            </div>
            <div class="full">
              <label>Descripción general</label>
              <textarea name="descripcion" placeholder="Describe el alcance del proyecto, instalación o paquete ofrecido"></textarea>
            </div>
            <div class="full">
              <label>Observaciones</label>
              <textarea name="observaciones" placeholder="Ejemplo: No incluye obra civil, sujeto a revisión final, precios sujetos a cambio, etc."></textarea>
            </div>
          </div>
        </div>

        <div class="section">
          <h2>Productos / conceptos</h2>

          <table id="productosTable">
            <thead>
              <tr>
                <th style="width:32%">Concepto</th>
                <th style="width:12%">Cantidad</th>
                <th style="width:18%">Precio Unitario</th>
                <th style="width:18%">Importe</th>
                <th style="width:20%">Acción</th>
              </tr>
            </thead>
            <tbody id="productosBody">
              <tr>
                <td><input type="text" name="concepto[]" placeholder="Ej. Cámara IP 2MP" required></td>
                <td><input type="number" step="1" min="0" name="cantidad[]" class="cantidad" required></td>
                <td><input type="number" step="0.01" min="0" name="precio[]" class="precio" required></td>
                <td><input type="text" class="importe" value="$0.00" readonly></td>
                <td><button type="button" class="btn btn-danger" onclick="eliminarFila(this)">Eliminar</button></td>
              </tr>
            </tbody>
          </table>

          <div class="actions">
            <button type="button" class="btn btn-secondary" onclick="agregarFila()">+ Agregar producto</button>
          </div>
        </div>

        <div class="section">
          <h2>Resumen</h2>
          <div class="summary">
            <div>
              <label>Condiciones adicionales</label>
              <textarea name="condiciones">La presente cotización está sujeta a disponibilidad de equipo. Los precios pueden cambiar sin previo aviso. El servicio de instalación se agenda una vez confirmado el anticipo o pago acordado.</textarea>
              <p class="note">Puedes ajustar este texto a tus políticas reales.</p>
            </div>

            <div class="totals">
              <div class="row">
                <span>Subtotal</span>
                <strong id="subtotalVista">$0.00</strong>
              </div>
              <div class="row">
                <span>IVA (16%)</span>
                <strong id="ivaVista">$0.00</strong>
              </div>
              <div class="row grand">
                <span>Total</span>
                <strong id="totalVista">$0.00</strong>
              </div>
            </div>
          </div>
        </div>

        <div class="actions">
          <button class="btn btn-secondary" type="submit" onclick="document.getElementById('modo_pdf').value='ver'">Ver PDF</button>
          <button class="btn btn-primary" type="submit" onclick="document.getElementById('modo_pdf').value='descargar'">Descargar PDF</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    function formatoMoneda(numero) {
      const n = Number(numero || 0);
      return '$' + n.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2});
    }

    function recalcularTotales() {
      const filas = document.querySelectorAll('#productosBody tr');
      let subtotal = 0;

      filas.forEach(fila => {
        const cantidad = parseFloat(fila.querySelector('.cantidad')?.value || 0);
        const precio = parseFloat(fila.querySelector('.precio')?.value || 0);
        const importe = cantidad * precio;
        subtotal += importe;

        const inputImporte = fila.querySelector('.importe');
        if (inputImporte) {
          inputImporte.value = formatoMoneda(importe);
        }
      });

      const iva = subtotal * 0.16;
      const total = subtotal + iva;

      document.getElementById('subtotalVista').textContent = formatoMoneda(subtotal);
      document.getElementById('ivaVista').textContent = formatoMoneda(iva);
      document.getElementById('totalVista').textContent = formatoMoneda(total);
    }

    function agregarFila() {
      const tbody = document.getElementById('productosBody');
      const tr = document.createElement('tr');

      tr.innerHTML = `
        <td><input type="text" name="concepto[]" placeholder="Ej. DVR 4 canales" required></td>
        <td><input type="number" step="1" min="0" name="cantidad[]" class="cantidad" required></td>
        <td><input type="number" step="0.01" min="0" name="precio[]" class="precio" required></td>
        <td><input type="text" class="importe" value="$0.00" readonly></td>
        <td><button type="button" class="btn btn-danger" onclick="eliminarFila(this)">Eliminar</button></td>
      `;

      tbody.appendChild(tr);
      enlazarEventos();
      recalcularTotales();
    }

    function eliminarFila(btn) {
      const filas = document.querySelectorAll('#productosBody tr');
      if (filas.length <= 1) {
        alert('Debe existir al menos un producto.');
        return;
      }
      btn.closest('tr').remove();
      recalcularTotales();
    }

    function enlazarEventos() {
      document.querySelectorAll('.cantidad, .precio').forEach(input => {
        input.removeEventListener('input', recalcularTotales);
        input.addEventListener('input', recalcularTotales);
      });
    }

    enlazarEventos();
    recalcularTotales();
  </script>
</body>
</html>