<?php
require_once __DIR__.'/auth.php';require_once __DIR__.'/app/bancos.php';ojb_admin();
header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');
try {
 if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);throw new InvalidArgumentException('Método inválido.');}
 $mid=(int)($_GET['movimiento_id']??0);$q=$pdo->prepare('SELECT * FROM oj_banco_movimientos WHERE id=?');$q->execute([$mid]);$movement=$q->fetch(PDO::FETCH_ASSOC);
 if(!$movement || $movement['tipo']!=='ingreso' || $movement['clasificacion']!=='negocio' || $movement['recibo_id'])throw new InvalidArgumentException('Selecciona un depósito de negocio sin recibo asociado.');
 $docId=(int)($_GET['documento_id']??0);
 if($docId>0) {
  // Una lectura consistente para total, recibos y saldo durante la vista previa.
  $pdo->beginTransaction();$summary=ojb_document_summary($pdo,$docId,$movement);$pdo->commit();
  echo json_encode(['ok'=>true,'documento'=>$summary],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);exit;
 }
 $text=ojr_text($_GET,'q',100);$escaped=str_replace(['\\','%','_'],['\\\\','\\%','\\_'],$text);$like='%'.$escaped.'%';
 $q=$pdo->prepare('SELECT id,folio,cliente_nombre,proyecto,total,tipo_documento FROM cotizaciones WHERE folio LIKE ? OR cliente_nombre LIKE ? OR proyecto LIKE ? ORDER BY id DESC LIMIT 30');$q->execute([$like,$like,$like]);
 $docs=[];foreach($q->fetchAll(PDO::FETCH_ASSOC) as $doc)$docs[]=['id'=>(int)$doc['id'],'folio'=>$doc['folio'],'cliente'=>$doc['cliente_nombre'],'proyecto'=>$doc['proyecto'],'total'=>ojr_centavos($doc['total']),'tipo'=>ojr_tipo($doc['tipo_documento']??'cotizacion')];
 echo json_encode(['ok'=>true,'documentos'=>$docs],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);
} catch(InvalidArgumentException $e) {if($pdo->inTransaction())$pdo->rollBack();if(http_response_code()===200)http_response_code(400);echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);}
catch(Throwable $e) {if($pdo->inTransaction())$pdo->rollBack();error_log('OJ buscar documentos: '.$e->getMessage());http_response_code(503);echo json_encode(['ok'=>false,'error'=>'No se pudo consultar el presupuesto. Recarga la página y revisa que las tablas de recibos estén disponibles.']);}
