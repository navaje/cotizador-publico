<?php
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/db.php';

$stmt = $pdo->query("
    SELECT id, folio, fecha, cliente_nombre, proyecto, total, tipo_documento
    FROM cotizaciones
    ORDER BY id DESC
");
$cotizaciones = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Listado de cotizaciones - Ojo Jarocho</title>

<style>
body{
    font-family: Arial, Helvetica, sans-serif;
    background:#eef3f8;
    margin:0;
    padding:24px;
    color:#1f2937;
}
.wrap{
    max-width:1200px;
    margin:0 auto;
    background:#fff;
    border-radius:14px;
    box-shadow:0 10px 30px rgba(0,0,0,.08);
    overflow:hidden;
}
.topbar{
    background:#0d3b66;
    color:#fff;
    padding:22px 28px;
}
.topbar h1{
    margin:0;
    font-size:28px;
}
.content{
    padding:24px;
}
.actions{
    margin-bottom:20px;
}
.btn{
    display:inline-block;
    background:#0d3b66;
    color:#fff;
    text-decoration:none;
    padding:10px 14px;
    border-radius:8px;
    font-weight:bold;
}

/* TABLA */
table{
    width:100%;
    border-collapse:collapse;
}
thead th{
    background:#0d3b66;
    color:#fff;
    padding:12px 10px;
    text-align:left;
    font-size:14px;
}
tbody td{
    border:1px solid #e5e7eb;
    padding:10px;
    font-size:14px;
}
tbody tr:nth-child(even){
    background:#f8fafc;
}

/* BOTONES */
.btn-group{
    display:flex;
    flex-wrap:wrap;
    gap:6px;
}
.inline-form{ display:inline-block; margin:0; }
.inline-form button{ border:0; cursor:pointer; }

.btn-sm{
    padding:7px 10px;
    border-radius:6px;
    font-size:12px;
    font-weight:bold;
    text-decoration:none;
}

/* COLORES */
.btn-pdf{ background:#0d3b66; color:#fff; }
.btn-wa{ background:#25D366; color:#fff; }
.btn-plano{ background:#82B60B; color:#fff; }
.btn-convert{ background:#dbe7f3; color:#0d3b66; }
.btn-firma{ background:#9333ea; color:#fff; }
.btn-delete{ background:#fee2e2; color:#b91c1c; }

.total{
    font-weight:bold;
}

.empty{
    padding:20px;
    background:#f9fafb;
    border:1px dashed #cbd5e1;
    border-radius:10px;
}

@media (max-width: 900px){
    table{
        display:block;
        overflow:auto;
    }
}
</style>
</head>

<body>

<div class="wrap">
    <div class="topbar">
        <h1>Listado de cotizaciones</h1>
    </div>

    <div class="content">

        <div class="actions">
            <a class="btn" href="index.php">+ Nueva cotización</a>
        </div>

        <?php if (count($cotizaciones) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Folio</th>
                    <th>Tipo</th>
                    <th>Fecha</th>
                    <th>Cliente</th>
                    <th>Proyecto</th>
                    <th>Total</th>
                    <th>Acciones</th>
                </tr>
            </thead>

            <tbody>
            <?php foreach ($cotizaciones as $row): ?>
                <tr>
                    <td><?= htmlspecialchars($row['folio']); ?></td>
                    <td><?= htmlspecialchars($row['tipo_documento']); ?></td>
                    <td><?= htmlspecialchars($row['fecha']); ?></td>
                    <td><?= htmlspecialchars($row['cliente_nombre']); ?></td>
                    <td><?= htmlspecialchars($row['proyecto']); ?></td>
                    <td class="total">$<?= number_format($row['total'], 2, '.', ','); ?></td>

                    <td>
                        <div class="btn-group">

                            <!-- PDF -->
                            <a class="btn-sm btn-pdf"
                               href="ver-cotizacion.php?id=<?= $row['id']; ?>" target="_blank">
                               PDF
                            </a>

                            <a class="btn-sm btn-pdf" href="anticipos.php?id=<?= (int)$row['id']; ?>">Recibos / Anticipos</a>
                            <?php if ($row['tipo_documento'] === 'nota_servicio'): ?>
                            <a class="btn-sm btn-plano" href="inspecciones.php?documento=<?= (int)$row['id']; ?>">Checklist CCTV / IP</a>
                            <?php endif; ?>
                            <!-- WhatsApp -->
                            <a class="btn-sm btn-wa"
                               href="whatsapp.php?id=<?= $row['id']; ?>" target="_blank">
                               WhatsApp
                            </a>

                            <!-- Plano -->
                            <a class="btn-sm btn-plano"
                               href="plano/?id=<?= $row['id']; ?>" target="_blank">
                               Plano
                            </a>

                            <!-- Convertir -->
                            <?php if ($row['tipo_documento'] === 'cotizacion'): ?>
                                <?php foreach (['nota_venta' => 'Nota venta', 'nota_servicio' => 'Nota servicio'] as $tipo => $etiqueta): ?>
                                <form class="inline-form" method="post" action="convertir_documento.php">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?= (int)$row['id']; ?>">
                                    <input type="hidden" name="tipo" value="<?= $tipo; ?>">
                                    <button class="btn-sm btn-convert" type="submit"><?= $etiqueta; ?></button>
                                </form>
                                <?php endforeach; ?>
                            <?php endif; ?>

                            <!-- Firma -->
                            <?php if (in_array($row['tipo_documento'], ['nota_venta','nota_servicio'])): ?>
                                <a class="btn-sm btn-firma"
                                   href="aceptacion.php?id=<?= $row['id']; ?>" target="_blank">
                                   Firma
                                </a>
                            <?php endif; ?>

                            <!-- Eliminar -->
                            <?php if (($_SESSION['usuario_rol'] ?? '') === 'admin'): ?>
                                <form class="inline-form" method="post" action="eliminar_documento.php" onsubmit="return confirm('¿Eliminar documento?');">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?= (int)$row['id']; ?>">
                                    <button class="btn-sm btn-delete" type="submit">Eliminar</button>
                                </form>
                            <?php endif; ?>

                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php else: ?>
            <div class="empty">
                No hay cotizaciones registradas todavía.
            </div>
        <?php endif; ?>

    </div>
</div>

</body>
</html>
